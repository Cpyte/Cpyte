import ctypes
import ctypes.util
import os
import struct
import subprocess
import sys
import warnings

from ._bignum_bc import load_bignum_bc
from .generate_bc import _remove_probe_stack_ir
from .linker import format_cc_diag, LinkerNotFoundError, Linker
from .ui import print_err, print_ok

# Suppress ctypes callback cleanup warning during shutdown (harmless)
warnings.filterwarnings(
    "ignore", category=RuntimeWarning, message="memory leak in callback function"
)

if getattr(sys, "frozen", False):
    _RUNTIME_C = os.path.join(getattr(sys, "_MEIPASS", ""), "runtime.c")
else:
    _RUNTIME_C = os.path.join(os.path.dirname(__file__), "runtime.c")

if getattr(sys, "frozen", False):
    _GC_RUNTIME_C = os.path.join(getattr(sys, "_MEIPASS", ""), "gc_runtime.c")
else:
    _GC_RUNTIME_C = os.path.join(os.path.dirname(__file__), "gc_runtime.c")

_llvm_cc_cache = None


def _find_llvm_cc():
    """Find a C compiler that supports -emit-llvm for JIT compilation.

    Tries clang first, then falls back to other compilers on PATH.
    Returns the compiler path or raises SystemExit with a clear message.
    """
    global _llvm_cc_cache
    if _llvm_cc_cache is not None:
        return _llvm_cc_cache
    import shutil

    for name in ("clang", "cc", "gcc"):
        exe = shutil.which(name)
        if exe:
            try:
                r = subprocess.run(
                    [exe, "-S", "-emit-llvm", "-O0", "-o", "/dev/null", "-xc", "-"],
                    input="int __x = 0;",
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if r.returncode == 0:
                    _llvm_cc_cache = exe
                    return exe
            except (OSError, subprocess.TimeoutExpired):
                continue
    print_err(
        "error: no C compiler found that supports -emit-llvm (needed for JIT).\n"
        "  Install clang, or use --aot mode which works with gcc.\n"
        "  On macOS: xcode-select --install\n"
        "  On Ubuntu/Debian: sudo apt install clang\n"
        "  On Fedora/RHEL: sudo dnf install clang"
    )
    raise SystemExit(1)


_callbacks: list = []


def _load_libc():
    """Open libc bypassing symbol interposition where possible.

    On macOS, tools like MallocStackLogging may interpose malloc/free with a
    private arena allocator whose pointers the interposed free() rejects
    ("pointer being freed was not allocated"). Using RTLD_FIRST forces dlsym
    to resolve to the real libSystem symbols so JIT'd malloc/free/realloc/
    calloc stay self-consistent.
    """
    if sys.platform == "darwin":
        RTLD_FIRST = 0x100
        try:
            return ctypes.CDLL(
                "/usr/lib/libSystem.B.dylib",
                mode=os.RTLD_NOW | RTLD_FIRST,
            )
        except OSError:
            pass
    return ctypes.CDLL(ctypes.util.find_library("c"))


_libc = _load_libc()
_libc.strlen.argtypes = [ctypes.c_char_p]
_libc.strlen.restype = ctypes.c_int
_libc.memcpy.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
_libc.memcpy.restype = ctypes.c_void_p
_libc.malloc.argtypes = [ctypes.c_size_t]
_libc.malloc.restype = ctypes.c_void_p


def _runtime_print(n: int):
    print(n)


def _runtime_print_int64(n: int):
    print(n)


def _runtime_print_uint64(n: int):
    if n < 0:
        # Handle unsigned interpretation
        n = n & ((1 << 64) - 1)
    print(n)


def _runtime_print_hex(n: int):
    if n < 0:
        n = n & ((1 << 64) - 1)
    print(f"0x{n:x}")


def _runtime_print_double(d: float):
    print(f"{d:.6f}")


def _runtime_print_str(s: bytes):
    if s is None:
        print("(null)")
    else:
        try:
            print(s.decode("utf-8"))
        except UnicodeDecodeError:
            print(repr(s))


def _runtime_cstr(s: str) -> int:
    """Copy a Python string into a libc heap buffer, returning its address."""
    raw = s.encode("utf-8")
    size = len(raw) + 1
    buf = ctypes.create_string_buffer(raw + b"\0")
    ptr = _libc.malloc(size)
    if not ptr:
        return 0
    ctypes.memmove(ptr, buf, size)
    return ctypes.cast(ptr, ctypes.c_void_p).value or 0


def _runtime_str_of_int64(n: int) -> int:
    return _runtime_cstr(str(n))


def _runtime_str_of_uint64(n: int) -> int:
    if n < 0:
        n = n & ((1 << 64) - 1)
    return _runtime_cstr(str(n))


def _runtime_str_of_ptr(n: int) -> int:
    if n < 0:
        n = n & ((1 << 64) - 1)
    return _runtime_cstr(f"0x{n:x}")


def _runtime_str_of_double(d: float) -> int:
    return _runtime_cstr(f"{d:.6f}")


def _runtime_input() -> int:
    return int(input())


def _runtime_input_str() -> bytes:
    return input().encode("utf-8")


# Array length registry (mirrors runtime.c side table).
_arr_registry: dict[int, int] = {}


def _runtime_array_register(ptr: int, n: int):
    _arr_registry[ptr] = n


def _runtime_array_len(ptr: int) -> int:
    return _arr_registry.get(ptr, 0)


def _runtime_array_unregister(ptr: int):
    _arr_registry.pop(ptr, None)


# Dynamic variable runtime (name-keyed tagged values).
(
    _DYN_NONE,
    _DYN_INT,
    _DYN_INT64,
    _DYN_UINT64,
    _DYN_CHAR,
    _DYN_BOOL,
    _DYN_DOUBLE,
    _DYN_STR,
    _DYN_BIG,
    _DYN_PTR,
) = range(10)

_dyn_table: dict[bytes, tuple[int, int]] = {}


def _dyn_is_numeric(kind: int) -> bool:
    return kind in (
        _DYN_INT,
        _DYN_INT64,
        _DYN_UINT64,
        _DYN_CHAR,
        _DYN_BOOL,
        _DYN_DOUBLE,
    )


def _dyn_bits_to_double(bits: int) -> float:
    return struct.unpack("<d", struct.pack("<Q", bits))[0]


def _dyn_double_to_bits(v: float) -> int:
    return struct.unpack("<Q", struct.pack("<d", v))[0]


def _runtime_assign(name: bytes, kind: int, data: int):
    _dyn_table[name] = (kind, data & ((1 << 64) - 1))


def _runtime_dyn_as(name: bytes, want_kind: int) -> int:
    entry = _dyn_table.get(name)
    if entry is None or entry[0] == _DYN_NONE:
        print(f"dynamic variable '{name}' has no value", file=sys.stderr)
        os.abort()
    k, data = entry
    if k == want_kind:
        return data
    if _dyn_is_numeric(k) and _dyn_is_numeric(want_kind):
        if k != _DYN_DOUBLE and want_kind != _DYN_DOUBLE:
            return data
        if k == _DYN_DOUBLE:
            v = _dyn_bits_to_double(data)
            return ctypes.c_int64(int(v)).value & ((1 << 64) - 1)
        if k == _DYN_UINT64:
            v = float(data)
        else:
            v = float(ctypes.c_int64(data).value)
        return _dyn_double_to_bits(v)
    if (k in (_DYN_STR, _DYN_PTR)) and (want_kind in (_DYN_STR, _DYN_PTR)):
        return data
    print(
        f"dynamic variable '{name}' type mismatch ({k} -> {want_kind})", file=sys.stderr
    )
    os.abort()


# Bigint helpers for the dynamic runtime, resolved lazily after JIT finalize.
_dyn_bigint_print = [None]
_dyn_bigint_to_str = [None]


def _runtime_dyn_truthy(name: bytes) -> int:
    entry = _dyn_table.get(name)
    if entry is None or entry[0] == _DYN_NONE:
        return 0
    k, data = entry
    if k == _DYN_DOUBLE:
        return 1 if _dyn_bits_to_double(data) != 0.0 else 0
    return 1 if data != 0 else 0


def _runtime_dyn_print(name: bytes):
    entry = _dyn_table.get(name)
    if entry is None or entry[0] == _DYN_NONE:
        print(0)
        return
    k, data = entry
    if k == _DYN_INT:
        print(ctypes.c_int32(data).value)
    elif k == _DYN_INT64:
        print(ctypes.c_int64(data).value)
    elif k == _DYN_UINT64:
        print(data)
    elif k == _DYN_CHAR:
        print(ctypes.c_int8(data & 0xFF).value)
    elif k == _DYN_BOOL:
        print(1 if data else 0)
    elif k == _DYN_DOUBLE:
        print(f"{_dyn_bits_to_double(data):.6f}")
    elif k == _DYN_STR:
        if data == 0:
            print("(null)")
        else:
            try:
                print(ctypes.string_at(data).decode("utf-8"))
            except UnicodeDecodeError:
                print(repr(ctypes.string_at(data)))
    elif k == _DYN_BIG:
        cb = _dyn_bigint_print[0]
        if cb is not None:
            cb(data)
        else:
            print(data)
    elif k == _DYN_PTR:
        print(f"0x{data:x}")
    else:
        print(0)


def _runtime_dyn_str(name: bytes) -> int:
    entry = _dyn_table.get(name)
    if entry is None or entry[0] == _DYN_NONE:
        return _runtime_cstr("0")
    k, data = entry
    if k == _DYN_INT:
        return _runtime_cstr(str(ctypes.c_int32(data).value))
    if k == _DYN_INT64:
        return _runtime_cstr(str(ctypes.c_int64(data).value))
    if k == _DYN_UINT64:
        return _runtime_cstr(str(data))
    if k == _DYN_CHAR:
        return _runtime_cstr(str(ctypes.c_int8(data & 0xFF).value))
    if k == _DYN_BOOL:
        return _runtime_cstr("1" if data else "0")
    if k == _DYN_DOUBLE:
        return _runtime_cstr(f"{_dyn_bits_to_double(data):.6f}")
    if k == _DYN_STR:
        if data == 0:
            return _runtime_cstr("")
        return _runtime_cstr(ctypes.string_at(data).decode("utf-8", "replace"))
    if k == _DYN_BIG:
        cb = _dyn_bigint_to_str[0]
        if cb is not None:
            return cb(data)
        return _runtime_cstr(str(data))
    if k == _DYN_PTR:
        return _runtime_cstr(f"0x{data:x}")
    return _runtime_cstr("0")


_bigint_from_str_cb = None


def _runtime_input_big():
    try:
        line = input()
    except EOFError:
        line = ""
    return _bigint_from_str_cb(line.strip().encode("utf-8"))


def optimize(mod, opt_level=3, opt_size=False):
    from llvmlite import binding

    binding.initialize_native_target()
    binding.initialize_native_asmprinter()
    if opt_level <= 0 and not opt_size:
        return
    target = binding.Target.from_default_triple()
    target_machine = target.create_target_machine()

    if opt_size:
        # -OSize: optimize purely for code size, completely ignoring speed.
        # Cap at O2 so the heavy O3/O4 speed passes never run, and disable every
        # size-bloating transformation (loop unrolling/vectorization, high
        # inlining). The default module pipeline then shrinks code.
        effective = min(opt_level, 2)
        pto = binding.create_pipeline_tuning_options(speed_level=0)
        pto.inlining_threshold = 25
        pto.loop_unrolling = False
        pto.loop_vectorization = False
        pto.slp_vectorization = False
        pto.loop_interleaving = False
    else:
        effective = opt_level
        pto = binding.create_pipeline_tuning_options(speed_level=min(opt_level, 3))

    heavy = effective >= 3
    extra_heavy = effective >= 4

    if effective >= 2:
        pto.slp_vectorization = True
    if heavy:
        pto.inlining_threshold = 450 if extra_heavy else 275
        pto.loop_unrolling = True
        pto.loop_vectorization = True
        pto.loop_interleaving = True

    pb = binding.create_pass_builder(target_machine, pto)

    # Phase 1: infer function attributes (readonly/noalias/nonnull) so every
    # later pass can exploit them (RPO function-attrs runs as a module pass).
    if heavy:
        mpm = pb.getModulePassManager()
        mpm.add_rpo_function_attrs_pass()
        mpm.run(mod, pb)

    # Phase 2: aggressive per-function simplification. Promote allocas to SSA,
    # fold constants, remove dead stores/blocks, and specialise loops.
    if effective >= 2:
        fpm = pb.getFunctionPassManager()
        fpm.add_simplify_cfg_pass()
        fpm.add_sroa_pass()
        fpm.add_instruction_combine_pass()
        if heavy:
            fpm.add_new_gvn_pass()  # global value numbering
            fpm.add_instruction_combine_pass()
            fpm.add_sccp_pass()  # sparse conditional constant propagation
            fpm.add_reassociate_pass()
            fpm.add_jump_threading_pass()
            fpm.add_loop_rotate_pass()
            fpm.add_loop_unroll_pass()
            fpm.add_loop_strength_reduce_pass()
            fpm.add_sinking_pass()
            fpm.add_mem_copy_opt_pass()
            fpm.add_dead_store_elimination_pass()
            fpm.add_tail_call_elimination_pass()
            fpm.add_aggressive_dce_pass()
        elif opt_size:
            # Size-friendly subset: fold constant branches, prune dead code and
            # tail-call-eliminate, but never unroll or vectorize loops.
            fpm.add_instruction_combine_pass()
            fpm.add_sccp_pass()
            fpm.add_jump_threading_pass()
            fpm.add_dead_store_elimination_pass()
            fpm.add_tail_call_elimination_pass()
            fpm.add_aggressive_dce_pass()
        fpm.add_simplify_cfg_pass()
        for fn in mod.functions:
            if not fn.is_declaration:
                fpm.run(fn, pb)

    # Phase 3: aggressive interprocedural module passes (by-ref promotion,
    # whole-module constant propagation, dead argument/function elimination,
    # function merging). These shrink and specialise the module before the
    # default pipeline runs the inliner and vectorizers.
    if heavy:
        mpm = pb.getModulePassManager()
        mpm.add_argument_promotion_pass()
        mpm.add_ipsccp_pass()
        mpm.add_global_opt_pass()
        mpm.add_constant_merge_pass()
        mpm.add_global_dead_code_eliminate_pass()
        mpm.add_dead_arg_elimination_pass()
        if extra_heavy:
            mpm.add_post_order_function_attributes_pass()
            mpm.add_aggressive_instcombine_pass()
            mpm.add_always_inliner_pass()
            mpm.add_partial_inliner_pass()
            mpm.add_merge_functions_pass()
        mpm.run(mod, pb)
    elif opt_size:
        # Size-oriented module phase: coalesce constants, eliminate dead globals
        # and arguments, merge identical function bodies, drop unused prototypes.
        mpm = pb.getModulePassManager()
        mpm.add_constant_merge_pass()
        mpm.add_global_dead_code_eliminate_pass()
        mpm.add_dead_arg_elimination_pass()
        mpm.add_merge_functions_pass()
        mpm.add_strip_dead_prototype_pass()
        mpm.run(mod, pb)

    # Default module pipeline (includes inliner, GVN, DCE, loop and vectorization opts)
    npm = pb.getModulePassManager()

    # Let extension hooks add their own passes
    try:
        from .extension_hooks import (
            CompilerContext,
            HookStage,
            OptimizeHook,
            get_global_hook_registry,
        )

        registry = get_global_hook_registry()
        ctx = CompilerContext(optimization_level=opt_level, llvm_module=mod)
        for hook in registry.get(HookStage.OPTIMIZE):
            if not isinstance(hook, OptimizeHook):
                continue
            try:
                if hook.should_add_passes(ctx):
                    hook.add_module_passes(npm, ctx)
            except Exception as e:
                print_err(
                    f"optimize hook {hook.__class__.__name__} failed: {e}"
                )
    except Exception:
        pass

    npm.run(mod, pb)


def _maybe_compile(module, use_native_eh=False):
    if isinstance(module, list):
        from .bytecoding import LLVM

        c = LLVM(use_native_eh=use_native_eh)
        prog, src_files = c.emit_program(module)
        return prog, src_files
    return module, None


def run_jit(
    module,
    opt_level=3,
    src_files=None,
    no_userspace=False,
    pic=False,
    use_native_eh=False,
):
    module, src_files_auto = _maybe_compile(module, use_native_eh=use_native_eh)
    if src_files_auto is not None:
        src_files = src_files_auto
    global _print_fn, _input_fn
    from llvmlite import binding

    binding.initialize_native_target()
    binding.initialize_native_asmprinter()

    llvm_ir = str(module)
    mod = binding.parse_assembly(llvm_ir)
    llvm_cc = _find_llvm_cc()
    if src_files:
        target = binding.Target.from_default_triple()
        for src in src_files:
            if src.endswith(".ll"):
                with open(src) as f:
                    src_ir = f.read()
            else:
                r = subprocess.run(
                    [
                        llvm_cc,
                        "-S",
                        "-emit-llvm",
                        "-O0",
                        "-target",
                        target.triple,
                        "-fno-stack-protector",
                        "-o",
                        "-",
                        src,
                    ],
                    capture_output=True,
                    text=True,
                )

                if r.returncode != 0:
                    print_err(f"error compiling {src}: {format_cc_diag(r.stderr)}")
                    raise SystemExit(1)
                src_ir = r.stdout
            src_ir = _remove_probe_stack_ir(src_ir)
            src_mod = binding.parse_assembly(src_ir)
            binding.link_modules(mod, src_mod)

    # Link the C runtime (print/assign/dynamic dispatch/array registry) so the
    # JIT can resolve native helpers that have no Python callback mirror.
    target = binding.Target.from_default_triple()
    r = subprocess.run(
        [
            llvm_cc,
            "-S",
            "-emit-llvm",
            "-O0",
            "-target",
            target.triple,
            "-fno-stack-protector",
            "-o",
            "-",
            _RUNTIME_C,
        ],
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        print_err(f"error compiling {_RUNTIME_C}: {format_cc_diag(r.stderr)}")
        raise SystemExit(1)
    runtime_mod = binding.parse_assembly(_remove_probe_stack_ir(r.stdout))
    binding.link_modules(mod, runtime_mod)

    bignum_mod = load_bignum_bc()
    binding.link_modules(mod, bignum_mod)

    # Compile the GC runtime from source at JIT time so it matches the host
    # platform (macOS/Linux/Windows) instead of relying on pre-built bitcode.
    r = subprocess.run(
        [
            llvm_cc,
            "-S",
            "-emit-llvm",
            "-O0",
            "-target",
            target.triple,
            "-fno-stack-protector",
            "-o",
            "-",
            _GC_RUNTIME_C,
        ],
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        print_err(f"error compiling {_GC_RUNTIME_C}: {format_cc_diag(r.stderr)}")
        raise SystemExit(1)
    gc_mod = binding.parse_assembly(_remove_probe_stack_ir(r.stdout))
    binding.link_modules(mod, gc_mod)

    mod.verify()
    optimize(mod, opt_level)
    mod.verify()

    target = binding.Target.from_default_triple()
    target_machine = target.create_target_machine()

    backing_mod = binding.parse_assembly("")
    engine = binding.create_mcjit_compiler(backing_mod, target_machine)
    engine.add_module(mod)

    if not no_userspace:
        cb = ctypes.CFUNCTYPE(None, ctypes.c_int)(_runtime_print)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_int"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_longlong)(_runtime_print_int64)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_int64"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_ulonglong)(_runtime_print_uint64)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_uint64"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_ulonglong)(_runtime_print_hex)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_hex"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_double)(_runtime_print_double)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_double"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_int)(_runtime_input)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("input_int"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_char_p)(_runtime_input_str)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("input_str"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p)(_runtime_input_big)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("bigint_input"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_char_p)(_runtime_print_str)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("print_str"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_longlong)(_runtime_str_of_int64)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("str_of_int64"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_ulonglong)(
            _runtime_str_of_uint64
        )
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("str_of_uint64"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_ulonglong)(_runtime_str_of_ptr)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("str_of_ptr"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_double)(_runtime_str_of_double)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("str_of_double"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_char_p, ctypes.c_int, ctypes.c_uint64)(
            _runtime_assign
        )
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("assign"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_uint64, ctypes.c_char_p, ctypes.c_int)(
            _runtime_dyn_as
        )
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("dyn_as"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_char_p)(_runtime_dyn_truthy)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("dyn_truthy"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_char_p)(_runtime_dyn_print)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("dyn_print"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_char_p)(_runtime_dyn_str)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("dyn_str"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_void_p, ctypes.c_longlong)(
            _runtime_array_register
        )
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("cpyte_array_register"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(ctypes.c_longlong, ctypes.c_void_p)(_runtime_array_len)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("cpyte_array_len"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

        cb = ctypes.CFUNCTYPE(None, ctypes.c_void_p)(_runtime_array_unregister)
        _callbacks.append(cb)
        try:
            engine.add_global_mapping(
                mod.get_function("cpyte_array_unregister"),
                ctypes.cast(cb, ctypes.c_void_p).value,
            )
        except NameError:
            pass

    _map_libc_fn(engine, mod, "malloc", ctypes.c_size_t, ctypes.c_void_p)
    _map_libc_fn(engine, mod, "free", None, None, argtypes=[ctypes.c_void_p])
    _map_libc_fn(
        engine,
        mod,
        "realloc",
        ctypes.c_void_p,
        ctypes.c_void_p,
        argtypes=[ctypes.c_void_p, ctypes.c_size_t],
    )
    _map_libc_fn(
        engine,
        mod,
        "calloc",
        ctypes.c_size_t,
        ctypes.c_void_p,
        argtypes=[ctypes.c_size_t, ctypes.c_size_t],
    )
    _map_libc_fn(engine, mod, "strlen", ctypes.c_char_p, ctypes.c_int)
    _map_libc_fn(
        engine,
        mod,
        "memcpy",
        None,
        ctypes.c_void_p,
        argtypes=[ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int],
    )
    _map_libc_fn(engine, mod, "atoi", ctypes.c_char_p, ctypes.c_int)
    _map_libc_fn(engine, mod, "atof", ctypes.c_char_p, ctypes.c_double)

    try:
        fn = mod.get_function("strcmp")
        engine.add_global_mapping(fn, _libc_addr("strcmp"))
    except NameError:
        pass

    engine.finalize_object()
    engine.run_static_constructors()

    global _bigint_from_str_cb
    _bigint_from_str_cb = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_char_p)(
        engine.get_function_address("bigint_from_str")
    )

    try:
        _dyn_bigint_print[0] = ctypes.CFUNCTYPE(None, ctypes.c_void_p)(
            engine.get_function_address("bigint_print")
        )
    except (NameError, RuntimeError):
        _dyn_bigint_print[0] = None
    try:
        _dyn_bigint_to_str[0] = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p)(
            engine.get_function_address("bigint_to_str")
        )
    except (NameError, RuntimeError):
        _dyn_bigint_to_str[0] = None

    func_ptr = engine.get_function_address("main")
    if not func_ptr:
        print_err("no `main` function defined")
        return 0
    _main_fn = ctypes.CFUNCTYPE(ctypes.c_int)(func_ptr)
    _callbacks.append(_main_fn)
    ret = _main_fn()
    return ret


def _libc_addr(name):
    """Return the raw address of a libc function.

    Returns the real libSystem implementation (RTLD_FIRST on macOS), avoiding
    allocator interposition that can break malloc/free round-trips in JIT'd
    code.
    """
    return ctypes.cast(getattr(_libc, name), ctypes.c_void_p).value


def _map_libc_fn(engine, mod, name, argtype, restype, argtypes=None):
    """Map an external libc symbol in the JIT module to its raw native address.

    Direct raw-address mapping (rather than an ffi closure) avoids the
    closure -> Python -> ctypes -> libffi round trip, which is fragile under
    malloc interposers and slower at runtime.
    """
    try:
        fn = mod.get_function(name)
    except NameError:
        return
    engine.add_global_mapping(fn, _libc_addr(name))


def run_aot(
    module,
    output="program.o",
    opt_level=3,
    src_files=None,
    no_userspace=False,
    pic=False,
    lto=False,
    frameworks=None,
):
    llvm_ir = str(module)
    from llvmlite import binding

    binding.initialize_native_target()
    binding.initialize_native_asmprinter()

    mod = binding.parse_assembly(llvm_ir)
    bignum_mod = load_bignum_bc()
    binding.link_modules(mod, bignum_mod)
    mod.verify()
    optimize(mod, opt_level)
    mod.verify()

    target = binding.Target.from_default_triple()
    if pic:
        target_machine = target.create_target_machine(reloc="pic")
    else:
        target_machine = target.create_target_machine()

    obj = target_machine.emit_object(mod)

    with open(output, "wb") as f:
        f.write(obj)

    objs = [output]
    try:
        linker = Linker(lto=lto)
    except LinkerNotFoundError as e:
        print_err(f"error: {e}")
        raise SystemExit(1)

    for src in src_files or []:
        src_obj = src.rsplit(".", 1)[0] + ".o"
        linker.compile_c(src, output=src_obj, opt_level=3, pic=pic)
        objs.append(src_obj)

    if not no_userspace:
        runtime_obj = output + ".runtime.o"
        linker.compile_c(_RUNTIME_C, output=runtime_obj, opt_level=3, pic=pic, eh=True)
        objs.append(runtime_obj)

    # Compile the GC runtime from source for the host platform (instead of
    # pre-built bitcode) — cross-platform on macOS/Linux/Windows.
    gc_obj = output + ".gc.o"
    linker.compile_c(_GC_RUNTIME_C, output=gc_obj, opt_level=3, pic=pic)
    objs.append(gc_obj)

    out_name = output.rsplit(".", 1)[0] if "." in output else output
    linker.link(objs, out_name, opt_level=3, pic=pic, frameworks=frameworks)


if getattr(sys, "frozen", False):
    _RUNTIME_SCORPION_C = os.path.join(
        getattr(sys, "_MEIPASS", ""), "runtime_scorpion.c"
    )
else:
    _RUNTIME_SCORPION_C = os.path.join(os.path.dirname(__file__), "runtime_scorpion.c")

_SCORPION_CC = "riscv32-unknown-elf-gcc"
_SCORPION_AS = "riscv64-elf-as"
_SCORPION_LD = "riscv64-elf-ld"
_SCORPION_OBJCOPY = "riscv64-elf-objcopy"
_SCORPION_ARCH = "-march=rv32imac_zicsr_zifencei_zba_zbb_zbs_zbkb"
_SCORPION_ABI = "-mabi=ilp32"


def _find_scorpion_tool(name, fallback):
    """Find a scorpion cross-compilation tool."""
    import shutil

    candidates = [
        f"riscv32-unknown-elf-{name}",
        f"riscv64-unknown-elf-{name}",
        f"riscv64-elf-{name}",
    ]
    for c in candidates:
        if shutil.which(c):
            return c
    return fallback


def run_scorpion(
    module, output="program.sef", opt_level=3, src_files=None, pic=False, exports=None
):
    """Compile a Cpyte module for Scorpion (RV32 bare-metal) producing a SEF file.
    Please use it good! :):)

    With pic=True the module is compiled with -fPIC and the final ELF is linked
    with --emit-relocs so it can be converted to a dynamic (SEF v2) image via
    WEW-scorpion/tools/elf2sef.py. `exports` names the symbols to mark as
    exported for dynamic linking (libraries).
    """
    from llvmlite import binding

    binding.initialize_all_targets()
    binding.initialize_all_asmprinters()

    llvm_ir = str(module)
    mod = binding.parse_assembly(llvm_ir)

    mod.verify()
    optimize(mod, opt_level)
    mod.verify()

    target = binding.Target.from_triple("riscv32-unknown-elf")
    if pic:
        target_machine = target.create_target_machine(reloc="pic")
    else:
        target_machine = target.create_target_machine()

    # Emit RV32 object file
    obj = target_machine.emit_object(mod)
    obj_file = output.rsplit(".", 1)[0] + ".o"
    with open(obj_file, "wb") as f:
        f.write(obj)

    objs = [obj_file]

    # Compile Scorpion runtime
    runtime_obj = output.rsplit(".", 1)[0] + ".runtime.o"
    cc = _find_scorpion_tool("gcc", _SCORPION_CC)
    cmd = [
        cc,
        "-c",
        "-O3",
        _SCORPION_ARCH,
        _SCORPION_ABI,
        "-nostdlib",
        "-ffreestanding",
        "-o",
        runtime_obj,
        _RUNTIME_SCORPION_C,
    ]
    if pic:
        cmd.append("-fPIC")  # This must be done to be ran on microcontrollers.
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print_err(f"error compiling runtime_scorpion.c: {format_cc_diag(r.stderr)}")
        raise SystemExit(1)
    objs.append(runtime_obj)

    # Link into ELF using the GCC driver so libgcc (e.g. __fixdfsi) is resolved
    elf_base = output.rsplit(".", 1)[0]
    elf_file = elf_base + ".elf"
    cc = _find_scorpion_tool("gcc", _SCORPION_CC)
    cmd = (
        [
            cc,
            _SCORPION_ARCH,
            _SCORPION_ABI,
            "-nostdlib",
            "-nostartfiles",
            "-Wl,-e,main",
            "-Wl,--no-relax",
            "-Wl,-Ttext=0",
            "-o",
            elf_file,
        ]
        + objs
        + ["-lgcc"]
    )
    if pic:
        cmd += ["-Wl,-q", "-Wl,--unresolved-symbols=ignore-all"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print_err(f"error linking: {format_cc_diag(r.stderr)}")
        raise SystemExit(1)

    if pic:
        # Dynamic SEF v2: relocation + import/export records
        elf2sef = os.path.join(
            os.path.dirname(os.path.dirname(_RUNTIME_SCORPION_C)),
            "..",
            "..",
            "WEW-scorpion",
            "tools",
            "elf2sef.py",
        )
        cmd = [sys.executable, elf2sef, elf_file, output]
        if exports:
            for name in exports:
                cmd += ["--export", name]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print_err(f"error converting to SEF: {format_cc_diag(r.stderr)}")
            raise SystemExit(1)
    else:
        # Static SEF v1 via mksef.py
        mksef = os.path.join(
            os.path.dirname(os.path.dirname(_RUNTIME_SCORPION_C)),
            "..",
            "..",
            "WEW-scorpion",
            "user",
            "mksef.py",
        )
        if not os.path.isfile(mksef):
            # Fallback: inline SEF generation using objdump/objcopy
            _elf_to_sef(elf_file, output, 0)
        else:
            r = subprocess.run(
                [sys.executable, mksef, elf_file, output],
                capture_output=True,
                text=True,
            )
            if r.returncode != 0:
                print_err(f"error converting to SEF: {format_cc_diag(r.stderr)}")
                raise SystemExit(1)

    print_ok(f"Wrote {os.path.getsize(output)} bytes to {output}")
    return elf_file


def _elf_to_sef(elf_path, sef_output, flags=0):
    """Convert ELF to SEF format without mksef.py."""
    import struct

    sections = {}
    result = subprocess.run(
        [
            _find_scorpion_tool("objdump", _SCORPION_LD.replace("ld", "objdump")),
            "-h",
            elf_path,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"error: objdump failed on {elf_path}", file=sys.stderr)
        raise SystemExit(1)

    for line in result.stdout.split("\n"):
        parts = line.split()
        if len(parts) >= 4 and parts[0].isdigit():
            name = parts[1]
            if name in (".text", ".rodata", ".data", ".bss"):
                sections[name] = int(parts[2], 16)

    result = subprocess.run(
        [
            _find_scorpion_tool("readelf", _SCORPION_LD.replace("ld", "readelf")),
            "-h",
            elf_path,
        ],
        capture_output=True,
        text=True,
    )
    entry = 0
    for line in result.stdout.split("\n"):
        if "Entry point address" in line:
            entry = int(line.split(":")[1].strip(), 16)

    bin_path = elf_path + ".bin"
    objcopy = _find_scorpion_tool("objcopy", _SCORPION_OBJCOPY)
    subprocess.run([objcopy, "-O", "binary", elf_path, bin_path], capture_output=True)

    with open(bin_path, "rb") as f:
        flat = f.read()
    os.unlink(bin_path)

    segments = []
    off = 0
    for sec in (".text", ".rodata", ".data"):
        if sec in sections:
            segments.append((0 if sec == ".text" else 1, off, sections[sec]))
            off += sections[sec]
    if ".bss" in sections:
        segments.append((2, off, sections[".bss"]))

    num = len(segments)
    hdr = 12 + num * 16

    out = bytearray()
    out += struct.pack("<IIHH", 0x00464553, entry, num, flags)
    dc = hdr
    for st, sv, ss in segments:
        out += struct.pack("<IIII", st, sv, ss, dc)
        dc += ss
    out += flat

    with open(sef_output, "wb") as f:
        f.write(out)
